export const categories = [
    {idCategorie: 0, nomCat:"Bébé"},
    {idCategorie: 1, nomCat:"Enfant"},
    {idCategorie: 2, nomCat:"Homme"},
    {idCategorie: 3, nomCat:"Femme"},
];
